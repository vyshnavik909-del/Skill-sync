# SkillSync — Student Success Hub

SkillSync is a front-end student productivity prototype that brings learning resources,
an AI study helper, task planning, study partners, internship tracking, and project
recommendations into one dashboard.

## Features

- Student dashboard and learning profile
- Learning resource library
- AI study helper (offline sample responses; optional Gemini connection)
- Tasks and study planner with browser local storage
- Study partner demo profiles and study-session planner
- Sample internship listings and demo application tracker
- Skill-based project recommendations and feasibility checker
- Responsive layout for desktop and mobile
- Demo sign-in screen, with optional Firebase Authentication integration

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Use the sign-in screen to enter demo mode. In demo mode, authentication is
   simulated locally; it does **not** create a real account or verify identity.
4. Explore the dashboard and features.

No build tools or package installation are required for the basic prototype.

## Deploy with GitHub Pages

1. Create a new repository on GitHub (for example, `skillsync`).
2. Upload `index.html`, `README.md`, `.gitignore`, and `LICENSE` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then click **Save**.
6. Wait for the deployment to finish. GitHub will show the published website URL
   in the Pages section.

## Optional integrations and important security notes

### Firebase Authentication

The HTML file contains placeholder Firebase web configuration values. Firebase
authentication is inactive until you create a Firebase project, enable the sign-in
providers you want, and replace the placeholders with your project's web-app
configuration. Add your deployed domain to Firebase Authentication's authorized
domains.

The prototype falls back to demo mode when Firebase is not configured. Demo mode
must not be described as secure authentication.

### Gemini AI

The AI helper can use offline sample answers. It also offers an optional Gemini API
key field for a private local demonstration. **Do not commit an API key to GitHub
or put a real secret in client-side HTML/JavaScript.** A browser-based key can be
exposed. For a public deployment, route AI requests through a backend service that
keeps the key in server-side environment variables.

## Prototype limitations

- Tasks, profile details, saved projects, and related demo data are stored in the
  visitor's browser using local storage; they are not synced to a server.
- Internship listings and study partner profiles are sample/demo data.
- Applying to an internship only records a demo action; it does not contact an employer.
- Firebase and Gemini integrations require separate configuration.
- GitHub Pages hosts static files; it does not provide a backend database or server.

## Tech used

- HTML5
- CSS3
- JavaScript
- Browser local storage
- Firebase Authentication SDK (optional, loaded from Google's CDN)

## Author

SkillSync prototype — student project.
